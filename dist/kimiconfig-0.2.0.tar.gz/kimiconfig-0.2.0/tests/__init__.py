"""
Тесты для пакета KimiConfig
""" 